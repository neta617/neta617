const info = getElementById('info');
const temp = getElementById('temp');
const ctx =  document.getElementById('chart').getContext('2d')

const chart = new chart(ctx, {
    type: 'line',
    data: {labels: [], datasets: [{ label: 'Uso Cpu (%)', data: [] }] },
    options: {scales: { y: { beginAtZero: true, max: 100} } }

});

async function actualizar() {
    const res = await fetch('/api/cpu');
    const data = await res.json();
    info.innerHTML = `
    <b>Modelo:</b> ${data.cpu.manufacturer} ${data.cpu.brand}<br>
    <b>Núcleos:</b> ${data.cpu.cores}</br>
    <b>Velocidad base</b> ${data.cpu.speed} Ghz
    
    `;
    temp.innerText = `🌡️temperatura: ${data.temp.main || '---'} °C`;

    chart.data.labels.push('');
    chart.data.datasets[0].data.push(data.load.currentLoad);
    
    if (chart.data.labels.length > 20) {

        chart.data.labels.shift();
        chart.data.datasets[0].data,shift();
    }
    chart.update();
}

setInterval(actualizar, 2000);