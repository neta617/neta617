const express = require('express');
const si = require('systeminformation');

const app = express();
app.use(express.static('public'));

app.get('/api/cpu', async (req, res) => {
  const cpu = await si.cpu();
  const temp = await si.cpuTemperature();
  const load = await si.currentLoad();
  res.json({ cpu, temp, load });
});

app.listen(3000, () => console.log('Servidor en http://localhost:3000'));